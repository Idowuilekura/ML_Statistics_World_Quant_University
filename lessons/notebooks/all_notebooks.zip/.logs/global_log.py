# Fri, 10 Jul 2020 16:23:05
%logstop
%logstart -rtq ~/.logs/ML_Intro_ML.py append
%matplotlib inline
import matplotlib
import seaborn as sns
sns.set()
matplotlib.rcParams['figure.dpi'] = 144